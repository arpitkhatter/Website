import styled from "styled-components";

const Timelines = (props) => {

    return (
        <Container>

        </Container>

    );    
}

const Container = styled.div`
    padding-top: 52px;
    max-width: 100%;
    padding-left: 25px;
    padding-right: 25px;
    background-color: #f3f2ef;
`;



export default Timelines;
