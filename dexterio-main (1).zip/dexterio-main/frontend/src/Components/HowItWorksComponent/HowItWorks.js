import React from 'react';

const HowItWorks = () => {
    return (
        <div>
            
        </div>
    );
};

export default HowItWorks;