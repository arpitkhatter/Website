const menuItems = [
    {
        title:'How it works',
        url:'#',
        cName:'nav-links'
    },
    {
        title:'Projects',
        url:'#',
        cName:'nav-links'
    },
    {
        title:'Prefab Interior',
        url:'#',
        cName:'nav-links'
    },
    {
        title:'Design Quiz',
        url:'#',
        cName:'nav-links'
    }
];